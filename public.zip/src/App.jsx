import React, { useMemo, useState } from 'react';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import { Wallet, ShieldCheck, User, Lightbulb } from 'lucide-react';

// Import sub-components
import StatCard from './components/StatCard';
import InsightsSection from './components/InsightsSection';
import TransactionList from './components/TransactionList';
import BalanceTrend from './components/BalanceTrend';
import AddTransactionModal from './components/AddTransactionModal';

// --- 1. Navbar Component (Requirement #3: Role Based UI) ---
const Navbar = () => {
  const { role, setRole } = useFinance();
  return (
    <nav className="bg-white border-b border-slate-200 px-8 py-4 flex justify-between items-center sticky top-0 z-10">
      <div className="flex items-center gap-2 font-bold text-xl text-indigo-600">
        <Wallet /> <span>FinanceTrack</span>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-full">
          <button 
            onClick={() => setRole('admin')}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
              role === 'admin' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'
            }`}
          >
            ADMIN
          </button>
          <button 
            onClick={() => setRole('viewer')}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
              role === 'viewer' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'
            }`}
          >
            VIEWER
          </button>
        </div>
      </div>
    </nav>
  );
};

// --- 2. Main Dashboard Logic (Requirement #1, #2, #4, #5) ---
const DashboardContent = () => {
  const { transactions, role, deleteTransaction } = useFinance();

  // State for Search and Filter
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");

  // Requirement #1: Calculate Summary totals
  const totals = useMemo(() => {
    return transactions.reduce(
      (acc, t) => {
        if (t.type === 'income') acc.income += t.amount;
        else acc.expense += t.amount;
        acc.balance = acc.income - acc.expense;
        return acc;
      },
      { income: 0, expense: 0, balance: 0 }
    );
  }, [transactions]);

  // Requirement #2: Filtering Logic for the Table
  const filteredTransactions = useMemo(() => {
    return transactions.filter((t) => {
      const descMatch = t.desc?.toLowerCase().includes(searchTerm.toLowerCase());
      const catMatch = t.category?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesSearch = descMatch || catMatch;
      const matchesType = filterType === "all" || t.type === filterType;
      return matchesSearch && matchesType;
    });
  }, [transactions, searchTerm, filterType]);

  // 1. Import the new modal at the top


const DashboardContent = () => {
  const { transactions, addTransaction, role } = useFinance(); // Add addTransaction here
  const [isModalOpen, setIsModalOpen] = useState(false); // State to open/close

  // ... (keep your existing totals and filteredTransactions logic) ...

  return (
    <main className="max-w-6xl mx-auto p-6 md:p-10">
      <header className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Overview</h1>
          <p className="text-slate-500 mt-1">Real-time financial tracking.</p>
        </div>
        
        {/* ADD THIS BUTTON - Requirement #5: Functional UI */}
        {role === 'admin' && (
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 flex items-center gap-2 transition-all"
          >
            <PlusCircle size={20} /> New Transaction
          </button>
        )}
      </header>

      {/* ... (rest of your summary cards, charts, etc.) ... */}

      {/* ADD THE MODAL COMPONENT AT THE BOTTOM */}
      <AddTransactionModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onAdd={addTransaction} 
      />
    </main>
  );
};
  // Requirement #4: Basic Insights Logic for Header
  const topExpense = useMemo(() => {
    const expenses = transactions.filter(t => t.type === 'expense');
    if (expenses.length === 0) return { category: "N/A", amount: 0 };
    
    const catMap = expenses.reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {});
    
    const top = Object.entries(catMap).sort((a, b) => b[1] - a[1])[0];
    return { category: top[0], amount: top[1] };
  }, [transactions]);


  
  return (
    <main className="max-w-6xl mx-auto p-6 md:p-10">
      <header className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Overview</h1>
          <p className="text-slate-500 mt-1">Real-time financial tracking and insights.</p>
        </div>
        
        <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-2xl flex items-center gap-3">
          <div className="bg-indigo-500 p-2 rounded-lg text-white">
            <Lightbulb size={20} />
          </div>
          <div>
            <p className="text-[10px] uppercase font-bold text-indigo-400 tracking-wider">Top Expense</p>
            <p className="text-sm font-bold text-indigo-900">{topExpense.category}: ${topExpense.amount}</p>
          </div>
        </div>
      </header>

      {/* Summary Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <StatCard title="Total Balance" amount={totals.balance} type="balance" />
        <StatCard title="Total Income" amount={totals.income} type="income" />
        <StatCard title="Total Expenses" amount={totals.expense} type="expense" />
      </div>

     {/* Chart Section */}
       <div className="mb-10 w-full"> 
         <BalanceTrend data={transactions} />
       </div>

      {/* Advanced Insights Section */}
      <InsightsSection transactions={transactions} totals={totals} />

      {/* Transactions Table Section */}
      <TransactionList 
        data={filteredTransactions || []} 
        role={role} 
        onDelete={deleteTransaction}
        onSearch={setSearchTerm}
        onFilter={setFilterType}
      />
      
      <footer className="mt-12 py-6 text-center border-t border-slate-100">
        <p className="text-slate-400 text-xs">FinanceTrack Dashboard &copy; 2026 | Built for Placement Submission</p>
      </footer>
    </main>
  );
};

// --- 3. Root App Component ---
export default function App() {
  return (
    <FinanceProvider>
      <div className="min-h-screen bg-slate-50 font-sans">
        <Navbar />
        <DashboardContent />
      </div>
    </FinanceProvider>
  );
}

import React from 'react';
import { Target, AlertCircle, Award } from 'lucide-react';

const InsightsSection = ({ transactions, totals }) => {
  // Logic: Calculate Savings Rate
  const savingsRate = totals.income > 0 
    ? (((totals.income - totals.expense) / totals.income) * 100).toFixed(1) 
    : 0;

  // Logic: Find the most frequent category
  const categories = transactions.map(t => t.category);
  const mostFrequent = categories.sort((a, b) =>
    categories.filter(v => v === a).length - categories.filter(v => v === b).length
  ).pop();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8 mb-10">
      <div className="bg-emerald-50 border border-emerald-100 p-6 rounded-2xl flex items-start gap-4">
        <div className="bg-emerald-500 p-3 rounded-xl text-white shadow-lg shadow-emerald-200">
          <Target size={24} />
        </div>
        <div>
          <h4 className="font-bold text-emerald-900">Savings Rate</h4>
          <p className="text-sm text-emerald-700 mt-1">
            You are saving <span className="font-bold">{savingsRate}%</span> of your total income this month.
          </p>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-100 p-6 rounded-2xl flex items-start gap-4">
        <div className="bg-amber-500 p-3 rounded-xl text-white shadow-lg shadow-amber-200">
          <AlertCircle size={24} />
        </div>
        <div>
          <h4 className="font-bold text-amber-900">Spending Habit</h4>
          <p className="text-sm text-amber-700 mt-1">
            Most of your transactions are in the <span className="font-bold">{mostFrequent}</span> category.
          </p>
        </div>
      </div>
    </div>
  );
};

export default InsightsSection;
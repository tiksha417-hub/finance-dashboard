import React from 'react';
import { TrendingUp, TrendingDown, CreditCard } from 'lucide-react';

const StatCard = ({ title, amount, type }) => {
  const isIncome = type === 'income';
  const isBalance = type === 'balance';

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-slate-500 uppercase tracking-wider">
          {title}
        </span>
        <div className={`p-2 rounded-lg ${
          isBalance ? 'bg-indigo-50 text-indigo-600' : 
          isIncome ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
        }`}>
          {isBalance ? <CreditCard size={20}/> : isIncome ? <TrendingUp size={20}/> : <TrendingDown size={20}/>}
        </div>
      </div>
      <div>
        <h3 className="text-3xl font-bold text-slate-900">
          ${amount.toLocaleString()}
        </h3>
        <p className="text-xs text-slate-400 mt-1">Updated just now</p>
      </div>
    </div>
  );
};

export default StatCard;
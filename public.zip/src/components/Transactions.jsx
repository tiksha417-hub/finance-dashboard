const { transactions, role, deleteTransaction } = useFinance();
const [searchTerm, setSearchTerm] = React.useState("");
const [filterType, setFilterType] = React.useState("all");

// Requirement #2: Simple filtering and search logic
const filteredTransactions = transactions.filter((t) => {
  const matchesSearch = t.desc.toLowerCase().includes(searchTerm.toLowerCase()) || 
                        t.category.toLowerCase().includes(searchTerm.toLowerCase());
  const matchesType = filterType === "all" || t.type === filterType;
  return matchesSearch && matchesType;
});
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const BalanceTrend = ({ data = [] }) => {
  return (
    /* FIX: We use an inline style for height. 
       Tailwind's 'h-80' can sometimes have a micro-delay in applying, 
       but inline styles are read instantly by Recharts.
    */
    <div 
      className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm w-full" 
      style={{ height: '350px', minWidth: '0' }} 
    >
      <h3 className="font-bold text-slate-800 mb-4">Balance Trend</h3>
      
      {data && data.length > 0 ? (
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis 
              dataKey="date" 
              axisLine={false} 
              tickLine={false} 
              tick={{fill: '#94a3b8', fontSize: 11}} 
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{fill: '#94a3b8', fontSize: 11}} 
            />
            <Tooltip 
              contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} 
            />
            <Area 
              type="monotone" 
              dataKey="amount" 
              stroke="#6366f1" 
              fillOpacity={1} 
              fill="url(#colorBalance)" 
              strokeWidth={3} 
              animationDuration={1000}
            />
          </AreaChart>
        </ResponsiveContainer>
      ) : (
        <div className="h-full flex items-center justify-center text-slate-400 italic text-sm">
          No transaction data to plot.
        </div>
      )}
    </div>
  );
};

export default BalanceTrend;
import React, { createContext, useState, useContext, useEffect } from 'react';

const FinanceContext = createContext();

export const FinanceProvider = ({ children }) => {
  const [role, setRole] = useState('admin'); // 'admin' or 'viewer'
  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('finance_data');
    return saved ? JSON.parse(saved) : [
      { id: 1, date: '2026-04-01', amount: 3000, category: 'Salary', type: 'income', desc: 'Monthly Pay' },
      { id: 2, date: '2026-04-02', amount: 50, category: 'Food', type: 'expense', desc: 'Lunch' },
      { id: 3, date: '2026-04-03', amount: 120, category: 'Bills', type: 'expense', desc: 'Internet' },
    ];
  });

  // Requirement #5: Handle state persistence
  useEffect(() => {
    localStorage.setItem('finance_data', JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (t) => setTransactions([...transactions, { ...t, id: Date.now() }]);
  
  const deleteTransaction = (id) => {
    if (role === 'admin') {
      setTransactions(transactions.filter(t => t.id !== id));
    }
  };

  return (
    <FinanceContext.Provider value={{ transactions, role, setRole, addTransaction, deleteTransaction }}>
      {children}
    </FinanceContext.Provider>
  );
};

const addTransaction = (newTx) => {
  setTransactions(prev => [newTx, ...prev]);
};

export const useFinance = () => useContext(FinanceContext);
